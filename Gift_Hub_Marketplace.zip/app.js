function scrollToProducts(){document.getElementById("products").scrollIntoView({behavior:"smooth"});}
function scrollToSell(){document.getElementById("sell").scrollIntoView({behavior:"smooth"});}

function openLogin(){document.getElementById("loginModal").style.display="flex";}
function closeLogin(){document.getElementById("loginModal").style.display="none";}
function openSellerForm(){document.getElementById("sellerModal").style.display="flex";}
function closeSellerForm(){document.getElementById("sellerModal").style.display="none";}

window.addEventListener("click",function(e){
  if(e.target.classList.contains("modal")){
    e.target.style.display="none";
  }
});

function searchProducts(){
  const query=document.getElementById("searchInput").value.toLowerCase().trim();
  document.querySelectorAll(".product-card").forEach(card=>{
    card.style.display=card.innerText.toLowerCase().includes(query)?"block":"none";
  });
}

function filterCategory(category){
  document.getElementById("products").scrollIntoView({behavior:"smooth"});
  document.querySelectorAll(".product-card").forEach(card=>{
    card.style.display=card.dataset.category===category?"block":"none";
  });
}

function buyProduct(name,price){
  const message=`Hello Gift Hub, I am interested in buying ${name} for KSh ${price.toLocaleString()}.`;
  window.location.href=`mailto:emmanuelouko21@gmail.com?subject=Gift Hub Order&body=${encodeURIComponent(message)}`;
}

function submitProduct(){
  const seller=document.getElementById("sellerName").value.trim();
  const name=document.getElementById("productName").value.trim();
  const price=document.getElementById("productPrice").value.trim();
  const category=document.getElementById("productCategory").value;
  const description=document.getElementById("productDescription").value.trim();

  if(!seller||!name||!price||!category||!description){
    alert("Please fill in all product details.");
    return;
  }

  const body=`Seller: ${seller}\nProduct: ${name}\nPrice: KSh ${price}\nCategory: ${category}\nDescription: ${description}`;
  window.location.href=`mailto:emmanuelouko21@gmail.com?subject=New Gift Hub Product Listing&body=${encodeURIComponent(body)}`;
  closeSellerForm();
}
